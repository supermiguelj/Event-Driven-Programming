package package1;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JInternalFrame;
import javax.swing.JLayeredPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.AbstractAction;
import javax.swing.Action;

public class Window {

	private JFrame frame;
	private JTextField itemID;
	private JTextField itemQuantity;
	private JTextField itemDetails;
	private JTextField currentSubtotal;
	private JTextField item1Display;
	private JTextField item2Display;
	private JTextField item3Display;
	private JTextField item4Display;
	private JTextField item5Display;
	private final Action action = new SwingAction();
	private final Action action_1 = new SwingAction_1();
	

	/**
	 * Launch the application.
	 */
	
	int itemCounter = 1;
	//Contains an array of the entire inventory
	//Item[] itemInventory = InputParser.initialize();
	
	private final Action action_2 = new SwingAction_2();
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Window window = new Window();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Window() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frame = new JFrame();
		frame.setBounds(100, 100, 1280, 721);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		itemID = new JTextField();
		itemID.setBounds(740, 30, 422, 28);
		frame.getContentPane().add(itemID);
		itemID.setColumns(10);
		
		itemQuantity = new JTextField();
		itemQuantity.setBounds(740, 69, 422, 28);
		itemQuantity.setColumns(10);
		frame.getContentPane().add(itemQuantity);
		
		itemDetails = new JTextField();
		itemDetails.setBounds(740, 108, 422, 28);
		itemDetails.setColumns(10);
		frame.getContentPane().add(itemDetails);
		
		currentSubtotal = new JTextField();
		currentSubtotal.setBounds(740, 147, 422, 28);
		currentSubtotal.setColumns(10);
		frame.getContentPane().add(currentSubtotal);
		
		JLabel lblItemID = new JLabel("Enter Item ID for Item #" + itemCounter + ":");
		lblItemID.setBounds(508, 30, 222, 28);
		frame.getContentPane().add(lblItemID);
		
		JLabel lblItemQ = new JLabel("Enter Item Quantity for Item #" + itemCounter + ":");
		lblItemQ.setBounds(508, 69, 222, 28);
		frame.getContentPane().add(lblItemQ);
		
		JLabel lblItemDetail = new JLabel("Details for Item #" + (itemCounter - 1) + ":");
		if (itemCounter == 1)
			lblItemDetail.setText("Details for Item #" + itemCounter + ":");
			//lblItemDetail = new JLabel("Details for Item #" + itemCounter + ":");
		lblItemDetail.setBounds(508, 118, 222, 28);
		frame.getContentPane().add(lblItemDetail);
		//Updates the label to reflect itemCounter conditional
		frame.revalidate();
		frame.repaint();
		
		JLabel lblCurrSubtotal = new JLabel("Current Subtotal for N item(s):");
		lblCurrSubtotal.setBounds(508, 147, 222, 28);
		frame.getContentPane().add(lblCurrSubtotal);
		
		item1Display = new JTextField();
		item1Display.setBounds(-59, 272, 1335, 20);
		frame.getContentPane().add(item1Display);
		item1Display.setColumns(10);
		
		item2Display = new JTextField();
		item2Display.setBounds(-59, 303, 1335, 20);
		item2Display.setColumns(10);
		frame.getContentPane().add(item2Display);
		
		item3Display = new JTextField();
		item3Display.setBounds(-59, 334, 1335, 20);
		item3Display.setColumns(10);
		frame.getContentPane().add(item3Display);
		
		item4Display = new JTextField();
		item4Display.setBounds(-59, 365, 1335, 20);
		item4Display.setColumns(10);
		frame.getContentPane().add(item4Display);
		
		item5Display = new JTextField();
		item5Display.setBounds(-59, 396, 1335, 20);
		item5Display.setColumns(10);
		frame.getContentPane().add(item5Display);
		
		JButton btnSearchItem = new JButton("Search For Item #" + itemCounter + ":");
		btnSearchItem.setAction(action_2);
		btnSearchItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Item[] itemInventory = InputParser.initialize();
				 for (Item tmpItem : itemInventory) {
					if (itemID.getText().equals(tmpItem.getID())) {
						itemDetails.setText(tmpItem.getName());
						frame.revalidate();
						frame.repaint();
					}
				} 
			}
		});
		btnSearchItem.setBounds(136, 482, 264, 38);
		frame.getContentPane().add(btnSearchItem);
		
		JButton btnViewCart = new JButton("View Cart");
		btnViewCart.setBounds(136, 543, 264, 38);
		frame.getContentPane().add(btnViewCart);
		
		JButton btnEmptyCart = new JButton("Empty Cart - Start A New Order");
		btnEmptyCart.setBounds(136, 602, 264, 38);
		btnEmptyCart.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		frame.getContentPane().add(btnEmptyCart);
		
		JButton btnAddItemn = new JButton("Add Item #" + itemCounter + " To Cart");
		btnAddItemn.setAction(action);
		btnAddItemn.setBounds(847, 482, 264, 38);
		btnAddItemn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		frame.getContentPane().add(btnAddItemn);
		
		JButton btnCheckOut = new JButton("Check Out");
		btnCheckOut.setBounds(847, 543, 264, 38);
		frame.getContentPane().add(btnCheckOut);
		
		JButton btnExitcloseApp = new JButton("Exit (Close App)");
		btnExitcloseApp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		btnExitcloseApp.setAction(action_1);
		btnExitcloseApp.setBounds(847, 602, 264, 38);
		frame.getContentPane().add(btnExitcloseApp);
		
		JLabel lblUserControls = new JLabel("USER CONTROLS");
		lblUserControls.setBounds(493, 427, 264, 44);
		lblUserControls.setFont(new Font("Century Gothic", Font.BOLD, 25));
		lblUserControls.setHorizontalAlignment(SwingConstants.CENTER);
		frame.getContentPane().add(lblUserControls);
	}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "Add Item #" + (itemCounter + 1) + " To Cart");
			putValue(SHORT_DESCRIPTION, "Adds current item to shopping cart");
		}
		public void actionPerformed(ActionEvent e) {
		}
	}
	private class SwingAction_1 extends AbstractAction {
		public SwingAction_1() {
			putValue(NAME, "Exit");
			putValue(SHORT_DESCRIPTION, "Closes Application");
		}
		public void actionPerformed(ActionEvent e) {
		}
	}
	private class SwingAction_2 extends AbstractAction {
		public SwingAction_2() {
			putValue(NAME, "Search For Item #" + itemCounter + ":");
			putValue(SHORT_DESCRIPTION, "Searches for item in inventory");
		}
		public void actionPerformed(ActionEvent e) {
		}
	}
}
