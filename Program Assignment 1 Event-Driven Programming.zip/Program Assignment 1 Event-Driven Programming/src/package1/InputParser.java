package package1;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class InputParser {
	//Why are these brackets mandatory??????
	//BufferedReader Block
	
	public static Item[] initialize() {
		try {
			//Used to store each line
			String line;
			//Line Reader
			BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\chevy\\eclipse-workspace\\Program Assignment 1 Event-Driven Programming\\src\\package1\\inventory.csv"));
			
			//number of columns
			int col = 5;
			//Creates 2D ArrayList with undefined rows
			ArrayList<ArrayList<String>> inventory = new ArrayList<>();
			
			//Reads through entire inventory.csv
			while ((line = br.readLine()) != null) {
				//Creates row for each line containing 5 elements
				ArrayList<String> row = new ArrayList<>(col);
				//Splits each line by comma
				String[] splitter = line.split(",");
				
				//populates the instantiated column ArrayList
				for (int j = 0; j < col; j++)
					row.add(splitter[j]);
				//adds column ArrayList to 2D ArrayTable
				inventory.add(row);
			}
			
			//Converts 2D list to 2D array
			
			//String[][] inventoryArr = new String[inventory.size()][];
			//for (int i = 0; i < inventory.size(); i++) {
				//inventoryArr[i] = inventory.get(i).toArray(new String[0]);
			//}
			
			Item[] itemInventory = new Item[inventory.size()];
			for (int i = 0; i < inventory.size(); i ++) {
				itemInventory[i] = new Item(inventory.get(i));
			}
			
			return itemInventory;
			
			/*Debug Only; tests by printing
			for (String[] row : inventoryArr) {
				for (String val : row)
					System.out.print(val + " ");
				System.out.println();
			}
			*/
			
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
		
		
		
	}

	
}

class Item {
	private String ID;
	private String name;
	private int quantity;
	private double price;
	
	public Item(ArrayList<String> inventoryCol) {
		this.ID = inventoryCol.get(0);
		this.name = inventoryCol.get(1);
		this.quantity = Integer.parseInt(inventoryCol.get(3).trim());
		this.price = Double.parseDouble(inventoryCol.get(4).trim());
	}

	public String getID() {
		return ID;
	}

	public String getName() {
		return name;
	}

	public int getQuantity() {
		return quantity;
	}

	public double getPrice() {
		return price;
	}
	
	
}